# Formula 1 Dashboard - Vercel Deployment

Modern Formula 1 Dashboard with race calendar, drivers, teams, standings & statistics.

## Quick Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/your-repo/tree/main/v0)

## Local Development

1. Install dependencies:
```bash
npm install
# or
pnpm install
```

2. Copy environment variables:
```bash
cp .env.example .env.local
```

3. Run the development server:
```bash
npm run dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment

This project is optimized for Vercel deployment. Simply:

1. Push this folder to your GitHub repository
2. Connect your repository to Vercel
3. Deploy automatically

## Environment Variables

Copy `.env.example` to `.env.local` and configure any necessary environment variables.

## Tech Stack

- **Framework**: Next.js 15
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI
- **Icons**: Lucide React
- **Charts**: Recharts
- **Forms**: React Hook Form + Zod
- **Testing**: Vitest + Testing Library